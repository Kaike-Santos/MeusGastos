package br.unasp.meusgastos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import br.unasp.meusgastos.ui.TelaGastos

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    TelaGastos(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun ResumoTotalPreview() {
    ResumoTotal(total = 201.70, quantidade = 4, modifier = Modifier.padding(16.dp))
}

@Preview(showBackground = true)
@Composable
private fun LinhaGastoPreview() {
    LinhaGasto(
        gasto = Gasto(1, "Almoço no bandejão", 18.50, Categoria.ALIMENTACAO),
        aoRemover = {},
        modifier = Modifier.padding(16.dp)
    )
}

@Preview(showBackground = true)
@Composable
private fun FormularioComErroPreview() {
    FormularioGasto(
        descricao = "Café", valorTexto = "abc",
        categoria = Categoria.ALIMENTACAO,
        erro = "O valor precisa ser um número",
        aoDigitarDescricao = {}, aoDigitarValor = {},
        aoSelecionarCategoria = {}, aoAdicionar = {},
        modifier = Modifier.padding(16.dp)
    )
}