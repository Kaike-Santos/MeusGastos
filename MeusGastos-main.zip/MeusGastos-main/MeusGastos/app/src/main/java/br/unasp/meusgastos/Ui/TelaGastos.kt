package br.unasp.meusgastos.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import br.unasp.meusgastos.model.Categoria
import br.unasp.meusgastos.model.Gasto
import br.unasp.meusgastos.viewmodel.GastosViewModel
import java.util.Locale

// ---------- Paleta ----------
private val Navy = Color(0xFF0F3A5F)
private val NavySuave = Color(0xFF4A6F8F)
private val Fundo = Color(0xFFEEF3F8)
private val Laranja = Color(0xFFF26B4B)
private val ChipFundo = Color(0xFFE1EAF3)
private val CampoFundo = Color(0xFFF3F6FA)
private val LinhaCampo = Color(0xFFBCD3E8)
private val Placeholder = Color(0xFF8CA5BB)

private fun moeda(valor: Double): String =
    String.format(Locale.forLanguageTag("pt-BR"), "R$ %,.2f", valor)

@Composable
fun TelaGastos(
    vm: GastosViewModel = viewModel(),
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Fundo)
            .padding(16.dp)
    ) {
        Text("Meus Gastos", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)

        Spacer(Modifier.height(14.dp))

        FormularioGasto(
            descricao = vm.descricao,
            valorTexto = vm.valorTexto,
            categoria = vm.categoriaSelecionada,
            erro = vm.erro,
            aoDigitarDescricao = vm::aoDigitarDescricao,
            aoDigitarValor = vm::aoDigitarValor,
            aoSelecionarCategoria = vm::aoSelecionarCategoria,
            aoAdicionar = vm::adicionar
        )

        Spacer(Modifier.height(16.dp))

        FiltroCategorias(selecionada = vm.filtro, aoFiltrar = vm::aoFiltrar)

        Spacer(Modifier.height(12.dp))

        ResumoTotal(total = vm.total, quantidade = vm.quantidade)

        Spacer(Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.gastosVisiveis) { gasto ->
                LinhaGasto(gasto = gasto, aoRemover = { vm.remover(gasto.id) })
            }
        }
    }
}

@Composable
fun FormularioGasto(
    descricao: String,
    valorTexto: String,
    categoria: Categoria,
    erro: String?,
    aoDigitarDescricao: (String) -> Unit,
    aoDigitarValor: (String) -> Unit,
    aoSelecionarCategoria: (Categoria) -> Unit,
    aoAdicionar: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {

            TextField(
                value = descricao,
                onValueChange = aoDigitarDescricao,
                placeholder = { Text("Descrição do gasto") },
                singleLine = true,
                colors = coresCampo(),
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TextField(
                    value = valorTexto,
                    onValueChange = aoDigitarValor,
                    placeholder = { Text("0,00") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    colors = coresCampo(),
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = aoAdicionar,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Navy)
                ) {
                    Text("Adicionar", fontWeight = FontWeight.Bold)
                }
            }

            if (erro != null) {
                Text(erro, color = Laranja, fontSize = 13.sp)
            }

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Categoria.entries.toList()) { c ->
                    Etiqueta(c.rotulo, ativa = c == categoria, aoClicar = { aoSelecionarCategoria(c) })
                }
            }
        }
    }
}

@Composable
fun FiltroCategorias(
    selecionada: Categoria?,
    aoFiltrar: (Categoria?) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyRow(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Etiqueta("Todas", ativa = selecionada == null, aoClicar = { aoFiltrar(null) })
        }
        items(Categoria.entries.toList()) { c ->
            Etiqueta(c.rotulo, ativa = selecionada == c, aoClicar = { aoFiltrar(c) })
        }
    }
}

@Composable
fun ResumoTotal(
    total: Double,
    quantidade: Int,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Navy)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text("Total", color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp)
            Text(moeda(total), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
        Text("$quantidade gasto(s)", color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
    }
}

@Composable
fun LinhaGasto(
    gasto: Gasto,
    aoRemover: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(gasto.descricao, color = Navy, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(gasto.categoria.rotulo, color = NavySuave, fontSize = 12.sp)
            }
            Text(moeda(gasto.valor), color = Navy, fontSize = 16.sp)
            Text(
                "remover",
                color = Laranja,
                fontSize = 13.sp,
                modifier = Modifier
                    .padding(start = 10.dp)
                    .clickable { aoRemover() }
            )
        }
    }
}

@Composable
fun Etiqueta(
    texto: String,
    ativa: Boolean,
    aoClicar: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(if (ativa) Laranja else ChipFundo)
            .clickable { aoClicar() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            texto,
            color = if (ativa) Color.White else NavySuave,
            fontWeight = if (ativa) FontWeight.Bold else FontWeight.Normal,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun coresCampo() = TextFieldDefaults.colors(
    focusedContainerColor = CampoFundo,
    unfocusedContainerColor = CampoFundo,
    focusedIndicatorColor = Navy,
    unfocusedIndicatorColor = LinhaCampo,
    focusedTextColor = Navy,
    unfocusedTextColor = Navy,
    cursorColor = Navy,
    focusedPlaceholderColor = Placeholder,
    unfocusedPlaceholderColor = Placeholder
)

@Preview(showBackground = true, heightDp = 780)
@Composable
private fun FiltroPreview() {
    FiltroCategorias(selecionada = Categoria.LAZER, aoFiltrar = {}, modifier = Modifier.padding(16.dp))
}
